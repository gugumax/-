import os

# 下面代码是用来关闭占用端口的程序，注意处理意外关闭程序导致的，后台进程无法关闭，占用端口问题
with os.popen('netstat -aon|findstr "23334"') as res:
	res = res.read().split('\n')
	result = []
	try:
		for line in res:
			temp = [i for i in line.split(' ') if i != '']
			if len(temp) > 4:
				print({'pid': temp[4], 'address': temp[1], 'state': temp[3]})
				os.popen(f"taskkill -pid {temp[4]} -f")
	except:
		pass

import socket
import threading
import time
import serial
import Contorller
from lists_confirm.code.ocr_utlis import *
import re
from LightGlue.tzpymain import *

ocr_config={
    "widthImg":640,
    "heightImg":480,
    "paperPoints":([283.0, 283.0], [514.0, 282.0], [288.0, 409.0], [523.0, 408.0]),
    "rotation":False,
    "sharpness":1,
    "Brightness":1.5,
    "Contrast":-70,
    "imgPath" : ".\list_img",
    "saveImgPath":".\list_img\imgFinal.png",
    "saveImgPathWithIndex": ".\list_img\imgFinal_{}.png"  # 新增格式化路径
}

# 设置图像路径
LightGlue_config = {
    "imgGiven": r"LightGlue/target/given.png",
    "imgJudge": r"LightGlue/target/judge.png",
    "saveGivenFinal": r"LightGlue/target/givenFinal.png",
    "saveJudgeFinal": r"LightGlue/target/judgeFinal.png",
    "saveJudgeFinalWithIndex": r"LightGlue/target/judgeFinal_{}.png",  # 新增格式化路径
    "paperPointsGiven":([218.0, 55.0], [473.0, 395.0], [218.0, 395.0], [473.0, 55.0]),
    "paperPointsJudge":([300.0, 59.0], [500.0, 326.0], [300.0, 326.0], [500.0, 59.0]),
    "widthImg": 480,
    "heightImg": 640,
}
lightglue_ismatch_value = 145

# object_name_orderA = ["红色方块","旺仔牛奶","可口可乐","东鹏特饮","乐事薯片","蒙牛牛奶"]

# object_name_ch =["红色方砖", "绿色方砖", "黄色方砖", "蓝色方砖", "旺仔牛奶", 
#                  "AD 钙奶", "李子园", "养乐多", "可口可乐", "百事可乐",
#                  "芬达", "雪碧", "东鹏特饮", "加多宝", "红牛",
#                  "王老吉", "乐事薯片", "品客薯片", "薯愿薯片", "可比克", 
#                 "蒙牛牛奶", "金典牛奶", "伊利牛奶", "特仑苏",
#                 "物品名称","物品数量"]

# object_map_num = [[29],[30],[31],[32],[24,27],
#                   [28],[8],[9],[19,34],[18,20],
#                   [22],[25],[21],[33],[26],
#                   [23],[2,3,4],[36,35],[5,6,7],[0,1,15,16,17],
#                   [12],[13,14],[11],[10]]       #当前最后一个标签为36

class SocketHandler:
    def __init__(self, port, handler):
        # 创建socket对象
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        # 绑定到本地主机和指定端口
        self.sock.bind(('localhost', port))
        # 开始监听连接
        self.sock.listen(1)
        # 创建并启动处理连接的线程
        self.thread = threading.Thread(target=handler, args=(self.sock, port))
        self.thread.daemon = True
        self.thread.start()
def location_handle(sock, port): #处理定位用的回调程序
    conn, addr = sock.accept()
    while True:
        data = conn.recv(1024)
        if data:
            try:
                global Cur_x, Cur_y, Cur_theta
                data_str = data.decode()  # 将数据解码为字符串
                data_str = data_str.replace('Position: (', '').replace(')', '')  # 去除不需要的字符
                Cur_x, Cur_y, Cur_theta = map(float, data_str.split(',')[:3])  # 提取前三个坐标值并转换为浮点数
                #print(f'Received from {port}: ', data)
            except:
                pass

def yolo_handle(sock, port):  #处理yolo用的回调程序
    conn, addr = sock.accept()
    global yolo_data_ready,photo_taken
    global goods_num
    global goods_poseX
    global goods_poseY
    global yolo_handle_i
    while True:
        data = conn.recv(1024)
        if data:
            #cprint(f'Received from {port}: ', data)
            data_str = data.decode('utf-8')  # 将字节串解码为字符串
            if data_str.strip()=="photo_taken":
                photo_taken.set()
            if data_str.strip() == "empty":
                goods_num = -1
                yolo_data_ready.set()
                continue  # 跳过后续处理
            items = re.split(r'Name:', data_str)  # 使用正则表达式按照'Name:'来分割字符串
            for item in items:
                if item:  # 忽略空字符串
                    # 检查数据是否符合预期的格式
                    if re.match(r'^[\w_]+,num:\d+,x:\d+,y:\d+$', item):
                        parts = item.split(',')  # 分割每个物品的数据
                        for part in parts:
                            if ':' in part:
                                key, value = part.split(':')  # 分割键和值
                                if key == 'num':
                                    goods_num = int(value)  # 将字符串转换为整数
                                elif key == 'x':
                                    goods_poseX = int(value)  # 将字符串转换为整数
                                elif key == 'y':
                                    goods_poseY = int(value)  # 将字符串转换为整数
                        # yolo_handle_i += 1
                        # if yolo_handle_i == 50:
                        #     print('YOLO goods_num=', goods_num, goods_poseX)
                        #     yolo_handle_i = 0
            yolo_data_ready.set()  # 标记数据已更新
            #print("yolo_data_ready set")



def send_to_location(client_socket, text): #发送给定位程序的数据，例如自旋180°
    try:
        client_socket.send(text.encode())
    except (BrokenPipeError, OSError):
        print(f"Send data error in port 23334")

def send_to_yolo(client_socket, text): #
    try:
        client_socket.send(text.encode())
    except (BrokenPipeError, OSError):
        print(f"Send data error in port 23336")

def connect_to_location(): #死循环连接定位程序socket，主要用于给定位程序发送反馈，例如自旋180°
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket.setblocking(True)#阻塞模式
    connected = False
    while not connected:
        try:
            client_socket.connect(('localhost', 23334))
            connected = True
            print("connect to location success")
        except :
            time.sleep(1)
    return client_socket

def connect_to_yolo(): #发送给yolo程序开始OCR识别
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket.setblocking(True)#阻塞模式
    connected = False
    while not connected:
        try:
            client_socket.connect(('localhost', 23336))
            connected = True
            print("connect to yolo success")
        except :
            time.sleep(1)
    return client_socket

yolo_handle_i = 0

Cur_x = 235 #机器人当前X坐标
Cur_y = 285 #机器人当前Y坐标
Cur_theta = 0 #机器人当前角度

Is_Finish = False #全部是否抓完
Is_Finish_firstseeA = False #A货架初见物品是否完成
Is_Finish_firstseeB = False #B货架初见物品是否完成
ShelvesAocr_Finish = False #A货架ocr上架是否完成
ShelvesBocr_Finish = False #B货架ocr上架是否完成
ocrcount_flag = 0 #ocr计数器
ocrthread_count = 0

goods_list_num = [1, 1, 0, 0] #二层购物清单   #养乐多-9不要了改成100 百事可乐不要了，由于特征匹配认错
goods_list_name = [[41,43,45,47],[24,27,34,36],[110],[100]]   #"营养快线","旺仔牛奶","百事可乐","养乐多"
total_list = [[41,43,45,47],[24,27,34,36],[110],[100],  [42],[21,48],[38],[33]]
# gohome_goods = ["营养快线","旺仔牛奶","百事可乐","养乐多"]
jiantou_num=[46, 13]

yolo_data_ready = threading.Event()
photo_taken=threading.Event()
ocr_worker_end = threading.Event()
stepper_motor_end = threading.Event()  #步进电机上升到第三层，多线程挂起时使用

# object_name_ch =["锐澳","东鹏","茶Π","加多宝"]
# object_map_num = [[42],[21,48],[38],[33]]       #当前最后一个标签为36

goods_Aocr_num = [1, 1]
goods_Aocr_name = [[33], [38]]   
good_Aocr_points = [[110,265], [146,265]]
goods_Bocr_num = [1, 1]
goods_Bocr_name = [[21,48], [42]] 
good_Bocr_points = [[146,265], [110,265]]

# object_name_gohome = ["营养快线","旺仔牛奶","百事可乐","养乐多"]
# object_map_gohome=[[41,43,45],[24,27,34,35,36,37],[18,20],[9]]      
# jiantou_num=[46]
# goods_list_num = [6] #购物清单   
# goods_list_name = [[28]]
goods_num = 0  #识别物品的标号，例如0表示薯片，1表示牛奶
goods_poseX = 0 #识别物品的X坐标
goods_poseY = 0 #识别物品的Y坐标
Target_goods_center = 400 #目标物品的中心坐标
diff_goods_center = 12 #目标物品的中心坐标运行误差
diff_last_x = 7
# goods_put_1 = [2,3,4,35,36,5,6,7,0,1,39,41,43,44,45,46]


#0-离家点、1-ocr点、2-货架A起点、3-货架A探测起始点、4-货架A探测结束点、5-货架A终点、
#6-A至B货架过渡矫姿点、7-货架B路口点、
#8-货架B起点、9-货架B探测起始点、10-货架B探测结束点、11-货架B终点、12-家里中心点
points=[[220,200],[210,80],[220,40],[120,30],[220,40],[220,200],
        [155,40],[220,45],
        [220,95],[220,83],[220,177],[225,220],[280,220]]

point_start=[230, 280] #起点坐标
point_end=[30, 30] #终点坐标 【25，25】
points_detectA = [[80,266],[180,266]] #A货架探测起始点和结束点
points_detectB = [[80,44],[180,44]] # B货架探测起始点和结束点
points_ocr_tofloor3A=[[92,265],[110,265],[128,265],[146,265],[164,265]]
points_ocr_tofloor3B=[[164,45],[146,45],[128,45],[110,45],[92,45]]
# points_ocr_tofloor3A=[[93,265],[111,265],[129,265],[147,265],[165,265]]
# points_ocr_tofloor3B=[[165,45],[147,45],[129,45],[111,45],[93,45]]
points_turn=[[40,265],[220,265],[40,45],[220,45]] #过渡点
point_Firstsee=[220,150] #初见物品拍照
def go_pose_fast(point,theta,Is_detecting):
    #print('开始去点')
    angle_dif = 5
    if(Is_detecting == 0):
        while (abs(Cur_x - point[0]) > 3 or abs(Cur_y - point[1]) > 3):
            angle_dif = Contorller.robot_sendgoal_fast(Cur_x, Cur_y, Cur_theta, point[0], point[1], theta, 150, Is_detecting)
        while (angle_dif > 3.1): # 确保自转角度到位
            angle_dif = Contorller.robot_sendgoal_fast(Cur_x, Cur_y, Cur_theta, point[0], point[1], theta, 0, Is_detecting)
        Contorller.robot_stop()
    elif(Is_detecting == 1):
        Contorller.robot_sendgoal(Cur_x, Cur_y, Cur_theta, point[0], point[1], theta, 50, Is_detecting)
def go_pose(point,theta,Is_detecting):
    #print('开始去点')
    angle_dif = 5
    if(Is_detecting == 0):
        while (abs(Cur_x - point[0]) > 2 or abs(Cur_y - point[1]) > 2):
            angle_dif = Contorller.robot_sendgoal(Cur_x, Cur_y, Cur_theta, point[0], point[1], theta, 100, Is_detecting)
        while (angle_dif > 3.1): # 确保自转角度到位
            angle_dif = Contorller.robot_sendgoal(Cur_x, Cur_y, Cur_theta, point[0], point[1], theta, 0, Is_detecting)
        Contorller.robot_stop()
    elif(Is_detecting == 1):
        Contorller.robot_sendgoal(Cur_x, Cur_y, Cur_theta, point[0], point[1], theta, 50, Is_detecting)
def go_pose_accurate(point,theta,Is_detecting):
    #print('开始去点')
    angle_dif = 5
    if(Is_detecting == 0):
        while (abs(Cur_x - point[0]) > 1.5 or abs(Cur_y - point[1]) > 1.5):
            angle_dif = Contorller.robot_sendgoal(Cur_x, Cur_y, Cur_theta, point[0], point[1], theta, 50, Is_detecting)
        while (angle_dif > 3.1): # 确保自转角度到位
            angle_dif = Contorller.robot_sendgoal(Cur_x, Cur_y, Cur_theta, point[0], point[1], theta, 0, Is_detecting)
        Contorller.robot_stop()
    elif(Is_detecting == 1):
        Contorller.robot_sendgoal(Cur_x, Cur_y, Cur_theta, point[0], point[1], theta, 50, Is_detecting)

#0-离家点、1-ocr点、2-货架A起点、3-货架A探测起始点、4-货架A探测结束点、5-货架A终点、
#6-A至B货架过渡矫姿点、7-货架B路口点、
#8-货架B起点、9-货架B探测起始点、10-货架B探测结束点、11-货架B终点、12-家里中心点

# 需考虑问题：同一位置货物抓取两次；提前完成任务标志，优化时间！！！！！！！！！！！！！！！！！！！！

#A and B货架上架
def Robot_put_good(A_or_B, i, last_x, temp): # A or B；第几层；last_x
    global goods_num
    global goods_Aocr_num
    global goods_Bocr_num
    global stepper_motor_end
    global ShelvesAocr_Finish
    global ShelvesBocr_Finish
    stepper_motor_end.clear() #清除事件标志
    print("上架物品")
    Contorller.robot_grab(i)    #控制机械臂抓取货物
    if(A_or_B == "A"):
        go_pose([last_x, points_detectA[0][1] + 15],0,0) #后退
        Contorller.robot_ready_put(0) #待上架状态
        stepper = threading.Thread(target=wait_stepper_motor)
        stepper.start() 
        go_pose([good_Aocr_points[temp][0],points_detectA[0][1] + 15],0,0) #到上货位置
        stepper_motor_end.wait(timeout=7) # 等待步进电机上升到第三层:
        Contorller.robot_put() #上架姿势
        go_pose_accurate([good_Aocr_points[temp][0], points_detectA[0][1] - 5],0,0) #前进
        Contorller.robot_put_down() #放下后抬起
        go_pose([good_Aocr_points[temp][0], points_detectA[0][1] + 15],0,0) #后退
        Contorller.robot_detect(i, 0) #探测第i层货架
        goods_num = -1
        goods_Aocr_num[temp] -= 1   #清单中物品的数量-1
        print("ocr:",goods_Aocr_name)
        print(goods_Aocr_num)
        if not any(goods_Aocr_num):
            ShelvesAocr_Finish = True
        if(ShelvesAocr_Finish == True and Is_Finish_firstseeA == True): #第二层任务完成，直接进入第一层任务
            return
        go_pose([last_x, points_detectA[0][1]],0,0)
    elif(A_or_B == "B"):
        go_pose([last_x, points_detectB[0][1] - 15],180,0) #后退
        Contorller.robot_ready_put(0) #待上架状态
        stepper = threading.Thread(target=wait_stepper_motor)
        stepper.start() 
        go_pose([good_Bocr_points[temp][0],points_detectB[0][1] - 15],180,0) #到上货位置
        stepper_motor_end.wait(timeout=7) # 等待步进电机上升到第三层:
        Contorller.robot_put() #上架姿势
        go_pose_accurate([good_Bocr_points[temp][0], points_detectB[0][1] + 5],180,0) #前进
        Contorller.robot_put_down() #放下后抬起
        go_pose([good_Bocr_points[temp][0], points_detectB[0][1] - 15],180,0) #后退
        Contorller.robot_detect(i, 0) #探测第i层货架
        goods_num = -1
        goods_Bocr_num[temp] -= 1   #清单中物品的数量-1
        print("ocr:",goods_Bocr_name)
        print(goods_Bocr_num)
        if not any(goods_Bocr_num):
            ShelvesBocr_Finish = True
        if(ShelvesBocr_Finish == True and Is_Finish_firstseeB == True): #第二层任务完成，直接进入第一层任务
            return 
        go_pose([last_x, points_detectB[0][1]],180,0)


# A and B货架抓取
def Robot_grab_good(A_or_B, i, last_x, temp,takehome=True): # A or B；第几层；last_x
    global goods_num
    global goods_list_num
    global goods_list_name
    print("抓取物品")
    if(9 in goods_list_name[temp]):
        Contorller.robot_grab(i, 1)    #控制机械臂抓取货物
    else:
        Contorller.robot_grab(i, 0)    #控制机械臂抓取货物
    if(A_or_B == "A"):
        go_pose([last_x, points_detectA[0][1] + 15],0,0) #后退
    elif(A_or_B == "B"):
        go_pose([last_x, points_detectB[0][1] - 15],180,0)
    Contorller.robot_back(0)
    Contorller.robot_detect(i, 1) #探测第i层货架
    if(A_or_B == "A"):
        go_pose([last_x, points_detectA[0][1]],0,0) #前进
    elif(A_or_B == "B"):
        go_pose([last_x, points_detectB[0][1]],180,0)
    if takehome == True:
        goods_num = -1
        goods_list_num[temp] -= 1   #清单中物品的数量-1
        print("list:",goods_list_name)
        print(goods_list_num)
        print("营养快线","旺仔牛奶","百事可乐","养乐多")
    else:
        pass
    # if not any(goods_list_num):
    #     Is_Finish = 1 # 购物清单物品都拿完

# def ocr_worker(ocr_config, point, A_or_B): #OCR处理程序(本来用于ocr多线程处理，但由于ocr处理时间占用太多资源，未使用)
#     global goods_Aocr_name,goods_Aocr_num,good_Aocr_points
#     global goods_Bocr_name,goods_Bocr_num,good_Bocr_points
#     global ocrcount_flag
#     global ocrthread_count
#     ocrthread_count += 1
#     now_ocrthread_count = ocrthread_count
#     ocr_result = ChecklistOCR(ocr_config)
#     if(A_or_B == "A"):
#         if(now_ocrthread_count >= 2):
#             ocr_worker_end.wait(timeout=20) # 等待OCR处理完成
#         if ocr_result and (ocr_result not in goods_Aocr_name): #如果识别到物品名称，并且不在列表中
#             goods_Aocr_name.append(ocr_result)  # 添加识别到的物品名称
#             goods_Aocr_num.append(1)         # 默认数量为1，可以根据需要调整
#             good_Aocr_points.append(point)
#             ocrcount_flag += 1
#             ocr_worker_end.set() #设置事件标志，表示OCR处理完成
#     elif(A_or_B == "B"):
#         if(now_ocrthread_count >= 2):
#             ocr_worker_end.wait(timeout=20) # 等待OCR处理完成
#         if ocr_result and (ocr_result not in goods_Bocr_name): #如果识别到物品名称，并且不在列表中
#             goods_Bocr_name.append(ocr_result)  # 添加识别到的物品名称
#             goods_Bocr_num.append(1)         # 默认数量为1，可以根据需要调整
#             good_Bocr_points.append(point)
#             ocrcount_flag += 1
#             ocr_worker_end.set() #设置事件标志，表示OCR处理完成

def wait_stepper_motor():
    global stepper_motor_end
    time.sleep(7.1)
    stepper_motor_end.set() #设置事件标志，表示步进电机上升到第三层完成



def is_firstsee_goods():
    global photo_taken
    photo_taken.clear()  # 清除事件标志
    send_to_yolo(yolo_socket_send,"到达位置拍照用于特征匹配")
    photo_taken.wait(timeout=1)
    match_result = lightglue_match(LightGlue_config,lightglue_ismatch_value,verbose=False)
    return match_result

def recognize_firstsee(): #拍照处理初见物品
    global photo_taken
    #拍照初见物品
    Contorller.robot_detect(2,0)
    go_pose_fast(points_turn[1],0,0)
    go_pose(point_Firstsee,-90,0)
    go_pose_accurate([point_Firstsee[0] - 10,point_Firstsee[1]],-90,0)
    Contorller.robot_stop()
    time.sleep(0.5)#拍照前防抖
    photo_taken.clear()  # 清除事件标志
    send_to_yolo(yolo_socket_send,"到达位置初见物品")
    # time.sleep(0.3)
    if photo_taken.wait(timeout=4) : # 等待最多5秒#给时间拍完，检测通信
        print("到达位置初见物品")
    else:
        print("等待超时，可能未收到数据")

def recognize_goods_A():
    global goods_num,goods_poseX,goods_poseY
    global goods_Aocr_num,goods_Aocr_name ,good_Aocr_points 
    global yolo_data_ready,photo_taken
    global Is_Finish_firstseeA
    global ocrcount_flag
    global ocrthread_count
    ocrthread_count = 0
    ocrcount_flag = 0
    jiantouflag = 0
    Is_recognize_ocrA = False
    i=0
    # goods_Aocr_name.clear()
    # goods_Aocr_num.clear()
    # good_Aocr_points.clear()
    # ocr_worker_end.clear() #清除事件标志
    Contorller.robot_detect(3,0)
    send_to_yolo(yolo_socket_send,"开始第三层的ocr")
    #扫完B货架后，扫A货架        
    go_pose(points_turn[1],0,0)
    # while Is_recognize_ocrA == False:
    #     go_pose(points_detectA[1],0,0)
    #     for point in points_ocr_tofloor3A[::-1]:
    #         go_pose_accurate(point,0, 0)
    #         print("到达位置识别 ",[Cur_x,Cur_y],point)
    #         jiantouflag = 0
    #         for i in range(10):
    #             yolo_data_ready.clear()  # 清除事件标志
    #             if yolo_data_ready.wait(timeout=2) :
    #                 if (goods_num in jiantou_num) :
    #                     jiantouflag = 1
    #                     break
    #         if jiantouflag == 1 and Is_Finish_firstseeA == False:
    #             print("✅ 箭头")
    #             while (abs(goods_poseX - Target_goods_center)>20) :
    #                 if(goods_poseX < Target_goods_center):#箭头在视野左侧
    #                     go_pose(points_detectA[0],0,1) #缓慢向左行驶
    #                 elif(goods_poseX > Target_goods_center):#箭头在视野右侧
    #                     go_pose(points_detectA[1],0,1) #缓慢向右行驶
    #             Contorller.robot_stop()
    #             time.sleep(0.2)#拍照前防抖
    #             photo_taken.clear()  # 清除事件标志
    #             send_to_yolo(yolo_socket_send,"到达位置拍照用于特征匹配")
    #             photo_taken.wait(timeout=1) 
    #             match_result = lightglue_match(LightGlue_config,lightglue_ismatch_value,verbose=False)
    #             if match_result:
    #                 print("📍 初见物品，要抓咯")
    #                 Robot_grab_good("A", 3, point[0], 0,takehome=False)
    #                 Is_Finish_firstseeA = True
    #                 if Is_recognize_ocrA ==True:
    #                     break
    #             else:
    #                 print("❌ 不是初见物品")
    #             continue # 跳过后续ocr处理
    #         if(jiantouflag == 0):
    #             print("🔍ocr")
    #             time.sleep(0.5)
    #             photo_taken.clear()  # 清除事件标志
    #             send_to_yolo(yolo_socket_send,"到达位置,准备ocr")
    #             photo_taken.wait(timeout=1) 
    #             ob_name = ChecklistOCR(ocr_config)
    #             if ob_name and (ob_name not in goods_Aocr_name): #如果识别到物品名称，并且不在列表中
    #                 goods_Aocr_name.append(ob_name)  # 添加识别到的物品名称
    #                 goods_Aocr_num.append(1)         # 默认数量为1，可以根据需要调整
    #                 good_Aocr_points.append(point)
    #                 ocrcount_flag += 1
    #             if ocrcount_flag >= 2 and Is_Finish_firstseeA == True:
    #                 break
    #     Is_recognize_ocrA = True
    go_pose(points_detectA[0],0,0)
    send_to_yolo(yolo_socket_send,"完成了第三层的ocr")
    print("完成了第三层的ocr")
    print("goods_Aocr_name:", goods_Aocr_name,"goods_Aocr_num:", goods_Aocr_num,"good_Aocr_points:", good_Aocr_points)

def recognize_goods_B():
    global goods_num,goods_poseX,goods_poseY
    global goods_Bocr_num,goods_Bocr_name ,good_Bocr_points
    global yolo_data_ready,photo_taken
    global Is_Finish_firstseeB
    global ocrcount_flag
    global ocrthread_count
    ocrthread_count = 0
    ocrcount_flag = 0
    jiantouflag = 0
    Is_recognize_ocrB = False
    i=0
    # goods_Bocr_name.clear()
    # goods_Bocr_num.clear()
    # good_Bocr_points.clear()
    # ocr_worker_end.clear() #清除事件标志
    Contorller.robot_detect(3,0)
    send_to_yolo(yolo_socket_send,"开始第三层的ocr")
    go_pose_fast(points_turn[2],180,0)
    # while Is_recognize_ocrB == False:
    #     go_pose(points_detectB[0],180,0)
    #     for point  in points_ocr_tofloor3B[::-1]:
    #     # for point  in points_ocr_tofloor3A[::-1]:#这是逆序
    #         go_pose_accurate(point, 180, 0)
    #         print("到达位置识别 ",[Cur_x,Cur_y],point)
    #         jiantouflag = 0
    #         for i in range(10):
    #             yolo_data_ready.clear()  # 清除事件标志
    #             if yolo_data_ready.wait(timeout=2) :
    #                 if (goods_num in jiantou_num) :
    #                     jiantouflag = 1
    #                     break
    #         if jiantouflag == 1 and Is_Finish_firstseeB==False:
    #             print("✅ 箭头")
    #             while (abs(goods_poseX - Target_goods_center)>20) :
    #                     if(goods_poseX < Target_goods_center):#箭头在视野左侧
    #                         go_pose(points_detectB[1],180,1) 
    #                     elif(goods_poseX > Target_goods_center):#箭头在视野右侧
    #                         go_pose(points_detectB[0],180,1) 
    #             Contorller.robot_stop()
    #             time.sleep(0.2)#拍照前防抖
    #             photo_taken.clear()  # 清除事件标志
    #             send_to_yolo(yolo_socket_send,"到达位置拍照用于特征匹配")
    #             photo_taken.wait(timeout=1)
    #             match_result = lightglue_match(LightGlue_config,lightglue_ismatch_value,verbose=False)
    #             if match_result:
    #                 print("📍 初见物品，要抓咯")
    #                 Robot_grab_good("B", 3, point[0], 0,takehome=False)
    #                 Is_Finish_firstseeB = True
    #                 if Is_recognize_ocrB == True:
    #                     break
    #             else:
    #                 print("❌ 不是初见物品")
    #             continue
    #         if(jiantouflag == 0):
    #         # print(goods_num,goods_poseX,point)
    #             print("🔍ocr")
    #             time.sleep(0.5)
    #             photo_taken.clear()  # 清除事件标志
    #             send_to_yolo(yolo_socket_send,"到达位置,准备ocr")
    #             photo_taken.wait(timeout=1)
    #             ob_name = ChecklistOCR(ocr_config)
    #             if ob_name and (ob_name not in goods_Bocr_name):
    #                 goods_Bocr_name.append(ob_name)  # 添加识别到的物品名称
    #                 goods_Bocr_num.append(1)         # 默认数量为1，可以根据需要调整
    #                 good_Bocr_points.append(point)
    #                 ocrcount_flag += 1
    #             if ocrcount_flag >= 2 and Is_Finish_firstseeB == True:
    #                 break
    #     Is_recognize_ocrB = True
    go_pose(points_detectB[1],180,0)
    send_to_yolo(yolo_socket_send,"完成了第三层的ocr")
    print("完成了第三层的ocr")
    print("goods_Bocr_name:", goods_Bocr_name,"goods_Bocr_num:", goods_Bocr_num,"good_Bocr_points:" ,good_Bocr_points)

def get_shelvesA():
    global goods_num
    global goods_poseX
    global goods_poseY
    global Is_Finish
    global Is_Finish_firstseeA
    global ShelvesAocr_Finish
    global points
    global goods_list_num
    global goods_Aocr_num
    global goods_Bocr_num
    global Target_goods_center
    Is_shelvesA = False
    last_x = 0
    # 前往起始点
    Contorller.robot_detect(2, 1)
    i=2
    while Is_shelvesA == False:
        while i>0:
            if (i%2==1 and (abs(Cur_x - points_detectA[0][0]) < 1 or Cur_x < points_detectA[0][0])) or (i%2==0 and (abs(Cur_x - points_detectA[1][0]) < 1 or Cur_x > points_detectA[1][0])):
                Contorller.robot_stop()
                i=i-1
                if(i>=1 and i<=2):
                    Contorller.robot_detect(i, 1) #探测第i层货架
                last_x = 0
            if i == 1:
                go_pose(points_detectA[0],0,1) #缓慢向左行驶
                if goods_num in jiantou_num and abs(goods_poseX - Target_goods_center)<diff_goods_center and (abs(Cur_x - last_x) > diff_last_x) and Is_Finish_firstseeA == False:
                    Contorller.robot_stop()   #则停止
                    time.sleep(0.25) # 等待0.25秒，停稳后记录坐标，因通信和电机反应需要时间
                    last_x = Cur_x
                    if(is_firstsee_goods() == True):
                        print("📍 初见物品，要抓咯")
                        Robot_grab_good("A", i, last_x, temp , takehome=False)
                        Is_Finish_firstseeA = True
                    else:
                        print("❌ 不是初见物品")
                        pass
                for temp,goods in enumerate(goods_Aocr_name): #检测当前货架上架货物
                    #若物品在购物清单中且还没拿完,且物品在中间位置，此处260是因为摄像头的中心和机械臂中心有偏移，若完全水平应该是320
                    #temp - 索引；goods - 储存的编号； goods_num - yolo传回的编号
                    if (goods_num in goods and goods_Aocr_num[temp]>0) and abs(goods_poseX - Target_goods_center)<diff_goods_center and (abs(Cur_x - last_x) > diff_last_x): 
                        Contorller.robot_stop()   #则停止
                        time.sleep(0.25) # 等待0.25秒，停稳后记录坐标，因通信和电机反应需要时间
                        last_x = Cur_x
                        Robot_put_good("A", i, last_x, temp)
                if(ShelvesAocr_Finish == True and Is_Finish_firstseeA == True): #
                    go_pose(points_detectA[0],0,0)
                    i=i-1
                    last_x = 0
            elif i == 2:
                go_pose(points_detectA[1],0,1) #缓慢向右行驶
                if goods_num in jiantou_num and abs(goods_poseX - Target_goods_center)<diff_goods_center and (abs(Cur_x - last_x) > diff_last_x) and Is_Finish_firstseeA == False:
                    Contorller.robot_stop()   #则停止
                    time.sleep(0.25) # 等待0.25秒，停稳后记录坐标，因通信和电机反应需要时间
                    last_x = Cur_x
                    if(is_firstsee_goods() == True):
                        print("📍 初见物品，要抓咯")
                        Robot_grab_good("A", i, last_x, temp, takehome=False)
                        Is_Finish_firstseeA = True
                    else:
                        print("❌ 不是初见物品")
                        pass
                for temp66,goods66 in enumerate(total_list):
                    if (goods_num in goods66) and abs(goods_poseX - Target_goods_center)<diff_goods_center and (abs(Cur_x - last_x) > diff_last_x):
                    #若物品在购物清单中且还没拿完,且物品在中间位置，此处260是因为摄像头的中心和机械臂中心有偏移，若完全水平应该是320
                    #temp - 索引；goods - 储存的编号； goods_num - yolo传回的编号
                        Contorller.robot_stop()   #则停止
                        time.sleep(0.25) # 等待0.25秒，停稳后记录坐标，因通信和电机反应需要时间
                        grab_flag66 = 0
                        last_x = Cur_x
                        for temp,goods in enumerate(goods_list_name):
                            if (goods_num in goods and goods_list_num[temp]>0): 
                                Robot_grab_good("A", i, last_x, temp)
                                grab_flag66 = 1
                                if not any(goods_list_num):
                                    Is_Finish = True # 购物清单物品都拿完
                        if grab_flag66 == 0 and Is_Finish_firstseeA == False:
                            if(is_firstsee_goods() == True):
                                print("📍 初见物品，要抓咯")
                                Robot_grab_good("A", i, last_x, temp, takehome=False)
                                Is_Finish_firstseeA = True
                            else:
                                print("❌ 不是初见物品")
                                pass
                if(Is_Finish == True and Is_Finish_firstseeA == True): #第二层任务完成，直接进入第一层任务
                    go_pose(points_detectA[1],0,0)
                    i=i-1
                    if(i>=1 and i<=2):
                        Contorller.robot_detect(i, 1) #探测第i层货架
                    last_x = 0
        go_pose_fast(points_turn[0],0,0) 
        Is_shelvesA = True

def get_shelvesB():
    global goods_num
    global goods_poseX
    global goods_poseY
    global Is_Finish
    global Is_Finish_firstseeB
    global ShelvesBocr_Finish
    global points
    global goods_list_num
    global goods_Aocr_num
    global goods_Bocr_num
    global Target_goods_center
    Is_shelvesB = False
    last_x = 0
    # 前往起始点
    Contorller.robot_detect(2, 1)
    i=2
    while Is_shelvesB == False:
        while i>0:
            if (i%2==1 and (abs(Cur_x - points_detectB[1][0]) < 1 or Cur_x > points_detectB[1][0])) or (i%2==0 and (abs(Cur_x - points_detectB[0][0]) < 1 or Cur_x < points_detectB[0][0])):
                Contorller.robot_stop()
                i=i-1
                if(i>=1 and i<=2):
                    Contorller.robot_detect(i, 1) #探测第i层货架
                last_x = 0
            if i == 1:
                go_pose(points_detectB[1],180,1) #缓慢向右行驶
                if goods_num in jiantou_num and abs(goods_poseX - Target_goods_center)<diff_goods_center and (abs(Cur_x - last_x) > diff_last_x) and Is_Finish_firstseeB == False:
                    Contorller.robot_stop()   #则停止
                    time.sleep(0.25) # 等待0.25秒，停稳后记录坐标，因通信和电机反应需要时间
                    last_x = Cur_x
                    if(is_firstsee_goods() == True):
                        print("📍 初见物品，要抓咯")
                        Robot_grab_good("B", i, last_x, temp, takehome=False)
                        Is_Finish_firstseeB = True
                    else:
                        print("❌ 不是初见物品")
                        pass
                for temp,goods in enumerate(goods_Bocr_name):
                    #若物品在购物清单中且还没拿完,且物品在中间位置，此处260是因为摄像头的中心和机械臂中心有偏移，若完全水平应该是320
                    #temp - 索引；goods - 储存的编号； goods_num - yolo传回的编号
                    if (goods_num in goods and goods_Bocr_num[temp]>0) and abs(goods_poseX - Target_goods_center)<diff_goods_center and (abs(Cur_x - last_x) > diff_last_x): 
                        Contorller.robot_stop()   #则停止
                        time.sleep(0.25) # 等待0.25秒，停稳后记录坐标，因通信和电机反应需要时间
                        last_x = Cur_x
                        Robot_put_good("B", i, last_x, temp)
                if(ShelvesBocr_Finish == True and Is_Finish_firstseeB == True): #第二层任务完成，直接进入第一层任务
                    go_pose([80,50],180,0)
                    i=i-1
                    last_x = 0
            elif i == 2:
                go_pose(points_detectB[0],180,1) #缓慢向左行驶
                if goods_num in jiantou_num and abs(goods_poseX - Target_goods_center)<diff_goods_center and (abs(Cur_x - last_x) > diff_last_x) and Is_Finish_firstseeB == False:
                    Contorller.robot_stop()   #则停止
                    time.sleep(0.25) # 等待0.25秒，停稳后记录坐标，因通信和电机反应需要时间
                    last_x = Cur_x
                    if(is_firstsee_goods() == True):
                        print("📍 初见物品，要抓咯")
                        Robot_grab_good("B", i, last_x, temp, takehome=False)
                        Is_Finish_firstseeB = True
                    else:
                        print("❌ 不是初见物品")
                        pass
                for temp66,goods66 in enumerate(total_list):
                    if (goods_num in goods66) and abs(goods_poseX - Target_goods_center)<diff_goods_center and (abs(Cur_x - last_x) > diff_last_x):
                    #若物品在购物清单中且还没拿完,且物品在中间位置，此处260是因为摄像头的中心和机械臂中心有偏移，若完全水平应该是320
                    #temp - 索引；goods - 储存的编号； goods_num - yolo传回的编号
                        Contorller.robot_stop()   #则停止
                        time.sleep(0.25) # 等待0.25秒，停稳后记录坐标，因通信和电机反应需要时间
                        grab_flag66 = 0
                        last_x = Cur_x
                        for temp,goods in enumerate(goods_list_name):
                            if (goods_num in goods and goods_list_num[temp]>0): 
                                Robot_grab_good("B", i, last_x, temp)
                                grab_flag66 = 1
                                if not any(goods_list_num):
                                    Is_Finish = True # 购物清单物品都拿完
                        if grab_flag66 == 0 and Is_Finish_firstseeB == False:
                            if(is_firstsee_goods() == True):
                                print("📍 初见物品，要抓咯")
                                Robot_grab_good("B", i, last_x, temp, takehome=False)
                                Is_Finish_firstseeB = True
                            else:
                                print("❌ 不是初见物品")
                                pass
                if(Is_Finish == True and Is_Finish_firstseeB == True): #第二层任务完成，直接进入第一层任务
                    go_pose(points_detectB[0],180,0)
                    i=i-1
                    if(i>=1 and i<=2):
                        Contorller.robot_detect(i, 1) #探测第i层货架
                    last_x = 0
        go_pose([80,50],180,0)
        go_pose([0,0],180,0)
        Is_shelvesB = True
def go_home():
    go_pose(points[11],0,0)
    Contorller.robot_detect(2)
    go_pose(points[12],0,0)
    Contorller.robot_posecorrect(3)

if __name__ == '__main__':
    yolo_socket = SocketHandler(23335, yolo_handle) # 创建yolo数据接收socket
    location_socket = SocketHandler(23333, location_handle) # 创建定位程序数据接收socket
    client_socket = connect_to_location() # 连接定位程序反馈socket
    yolo_socket_send =connect_to_yolo()

    Contorller.read_ok() #程序启动
    time.sleep(10)  #等待十秒
    recognize_firstsee() #拍照处理初见物品
    recognize_goods_A()  # 获取ocr识别的物体名称和数量
    get_shelvesA() #抓取A货架物品
    recognize_goods_B() # 获取ocr识别的物体名称和数量
    get_shelvesB() #抓取B货架物品
    time.sleep(150) 
    # match_result = lightglue_match(LightGlue_config,lightglue_ismatch_value,verbose=False)
# if __name__ == '__main__':
#     yolo_socket = SocketHandler(23335, yolo_handle) # 创建yolo数据接收socket
#     location_socket = SocketHandler(23333, location_handle) # 创建定位程序数据接收socket
#     client_socket = connect_to_location() # 连接定位程序反馈socket
#     yolo_socket_send =connect_to_yolo()

#     Contorller.read_ok()
#     time.sleep(2)
#     recognize_firstsee() #拍照处理初见物品
#     recognize_goods_A()  # 获取ocr识别的物体名称和数量
#     get_shelvesA()
#     go_pose([180,260],0,0)
#     go_pose([260,310],0,0)
#     # recognize_goods_B()
#     # get_shelvesB()
#     time.sleep(150)

    # ob_name = ChecklistOCR(ocr_config)
    # print("识别到的物品名称:", ob_name)

    # goods_Bocr_name.clear()
    # goods_Bocr_num.clear()
    # good_Bocr_points.clear()
    # ocr_worker_end.clear() #清除事件标志

    # for i in range(100):
    #     if(i == 5):
    #         ocr = threading.Thread(target=ocr_worker, args=(ocr_config, [130,130], "B")) # 创建OCR线程
    #         ocr.start()
    #     if(i == 20):
    #         ocr = threading.Thread(target=ocr_worker, args=(ocr_config, [130,130], "B")) # 创建OCR线程
    #         ocr.start()
    #     if(i == 30):
    #         print("完成了第三层的ocr")
    #         print("goods_Bocr_name:", goods_Bocr_name,"goods_Bocr_num:", goods_Bocr_num,"good_Bocr_points:" ,good_Bocr_points)
    #     print(i)
    #     time.sleep(1)


    #  Contorller.read_ok()
    #  time.sleep(15)
    #  recognize_goods()  # 获取ocr识别的物体名称和数量
    #  get_shelvesA()  
    #  get_shelvesB()
    #  go_home()

# if __name__ == '__main__':
#     yolo_socket = SocketHandler(23335, yolo_handle)#创建yolo数据接收socket
#     location_socket = SocketHandler(23333, location_handle)#创建定位程序数据接收socket
#     client_socket = connect_to_location()#连接定位程序反馈socket
#     yolo_socket_send =connect_to_yolo()

#     Contorller.read_ok()
#     Contorller.robot_detect(1)
#     while(1):
#         go_pose(points[4],1,0) #缓慢向右行驶
#         for temp,goods in enumerate(goods_list_name):
#                 #若物品在购物清单中且还没拿完,且物品在中间位置，此处260是因为摄像头的中心和机械臂中心有偏移，若完全水平应该是320
#                 if (goods_num in goods and goods_list_num[temp]>0) and abs(goods_poseX-315)<28 : 
#                         Contorller.robot_stop()   #则停止
#                         Contorller.robot_posecorrect(0.4)
#                         time.sleep(0.25)
#                         Contorller.robot_grab(1)    #控制机械臂抓取货物
#                         Contorller.robot_put(0)
#                         Contorller.robot_detect(1)      #探测第i层货架
#                         time.sleep(0.25)
#                         goods_num = -1
#                         goods_list_num[temp] -= 1 #清单中物品的数量-1
#                         print(goods_list_name)
#                         print(goods_list_num)
        #go_pose(points[3],1,1) #缓慢向左行驶

#=============================重启程序=================！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！
# if __name__ == '__main__':
#      yolo_socket = SocketHandler(23335, yolo_handle)#创建yolo数据接收socket
#      location_socket = SocketHandler(23333, location_handle)#创建定位程序数据接收socket
#      client_socket = connect_to_location()#连接定位程序反馈socket
#      yolo_socket_send =connect_to_yolo()
    
#      Contorller.read_ok()
#      time.sleep(10)
#      recognize_goods()  # 获取ocr识别的物体名称和数量
#      get_shelvesA()  
#      go_pose(points[7],0,0)
#      jiaozi(177,0)
#      go_pose(points[11],0,0)
#      jiaozi(177,0)
#      Contorller.robot_detect(2)
#      Contorller.robot_revolve(170)
#      jiaozi(-3,0)
#      go_pose(points[12],0,0)
#      jiaozi(-3,0)
#      Contorller.robot_posecorrect(3)


#     #=============================机器人运动到ocr观测位置后停止================================
# if __name__ == '__main__':
#     location_socket = SocketHandler(23333, location_handle)#创建定位程序数据接收socket
#     client_socket = connect_to_location()#连接定位程序反馈socket

#     Contorller.read_ok()
#     go_pose(points[0],0,0)
#     jiaozi(-3,0)
#     go_pose(points[1],0,0)
#     jiaozi(-3,0)
#     Contorller.robot_posecorrect(1.8) #机器人姿态校正
#     while(abs(Cur_y - 105) > 2 or Cur_y < 105):
#         go_pose(points[1],1,1)
#     Contorller.robot_poseback(0.4)
#     jiaozi(-3,0)
#     Contorller.robot_posecorrect(0.6)
#     Contorller.robot_detect(0) #0表示识别清单
    

    #==============================机器人依次抓取一二三层货物==================================
# if __name__ == '__main__':
#     Contorller.read_ok()
#     while (1):
#         Contorller.robot_detect(1)
#         Contorller.robot_grab(1)
#         Contorller.robot_put(0)
#         Contorller.robot_detect(1)
#         Contorller.robot_detect(2)
#         Contorller.robot_grab(2)
#         Contorller.robot_put(0)
#         Contorller.robot_detect(2)
#         Contorller.robot_detect(3)
#         Contorller.robot_grab(3)
#         Contorller.robot_put(0)
#         Contorller.robot_detect(3)
#         Contorller.robot_detect(1)
#         Contorller.read_ok()
    
    #=============================机器人运动到ocr位置，识别后回家============================
# if __name__ == '__main__':
#     yolo_socket = SocketHandler(23335, yolo_handle)#创建yolo数据接收socket
#     location_socket = SocketHandler(23333, location_handle)#创建定位程序数据接收socket
#     client_socket = connect_to_location()#连接定位程序反馈socket
#     yolo_socket_send =connect_to_yolo()

#     Contorller.read_ok()
#     recognize_goods()
#     go_pose(points[1],0,0)
#     time.sleep(0.5)
#     go_pose(points[0],0,0)
#     time.sleep(0.5)
#     go_pose(points[12],0,0)     #回到起点

    #=============================机器人不跑ocr直接货架购物===============================
# if __name__ == '__main__':
#     yolo_socket = SocketHandler(23335, yolo_handle)#创建yolo数据接收socket
#     location_socket = SocketHandler(23333, location_handle)#创建定位程序数据接收socket
#     client_socket = connect_to_location()#连接定位程序反馈socket
#     yolo_socket_send =connect_to_yolo()

#     Contorller.read_ok()
#     go_pose(points[0],0,0)
#     jiaozi(-3,0)
#     get_shelvesA()  
#     get_shelvesB()
#     go_home()
#     go_pose(points[12],0,0)     #回到起点

# def test():
#     global goods_num
#     # global
#     Is_test_ocr = False
#     jiantouflag=0
#     Contorller.robot_detect(3,0)
#     go_pose(points_turn[3],0,0)
#     go_pose_accurate(points_detectA[0],0,0)
#     # print("开始测试")
#     while True:
#         # go_pose(points_turn[3],0,0)
#         go_pose_accurate(points_detectA[0],0,0)
#         time.sleep(0.5)
#         for point  in points_ocr_tofloor3A:
#             go_pose_accurate(point, 0, 0)
#             # goods_num=-1
#             print("到达位置识别 ")
#             # time.sleep(0.2)
#             for i in range(5):
#                 yolo_data_ready.clear()  # 清除事件标志
#                 if yolo_data_ready.wait(timeout=5) :
#                     if (goods_num in jiantou_num) :
#                         jiantouflag = 1
#                         break
#             if jiantouflag == 1:
#                 jiantouflag = 0
#                 print("✅ 箭头")
#                 continue
#             # print(goods_num,goods_poseX,point)
#             print("❌ocr")
#             time.sleep(0.5)
#             send_to_yolo(yolo_socket_send,"到达位置,准备ocr")
#             time.sleep(1)
#             ob_name = ChecklistOCR(ocr_config)
#             time.sleep(3)
#             # print([Cur_x,Cur_y],ob_name)
#         # send_to_yolo(yolo_socket_send,"完成了第三层的ocr")
#         # print("完成了第三层的ocr")
#             # Is_test_ocr = True
    

#             # print("到达位置，准备ocr")
#             # flagcount += 1
#             # if flagcount >= 2:
#             #     Is_test = True
#             #     break
#     go_pose(points_turn[0],0,0)
#     go_pose(point_start,0,0)


