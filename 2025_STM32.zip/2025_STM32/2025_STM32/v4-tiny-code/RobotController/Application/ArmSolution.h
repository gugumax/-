#ifndef _ArmSolution_H_
#define _ArmSolution_H_
#include "main.h"


// �������״̬���Ͷ������
#define MAX_STATES 10
#define NUM_SERVOS 5  // ����ʹ��ǰ5�����

#define Servo0_OPEN_Angle 75
#define Servo0_CLOSE_Angle 112

extern uint16_t SETangles[NUM_SERVOS];
extern uint16_t init_angles[5];
//extern uint16_t armspeed[3];
extern uint32_t Stepper_Position[4];
//void Arm_init();
void ArmDriver_Init(void);
void SetServoAngle(int nServo,float angle);
uint8_t ServoTunnerOK(void);
void Servo_init(uint8_t nServo,int angle);
void slowPwm(uint8_t nServo);

void ArmSolution(double x,double y);
void Arm_Grab_floor1();
void Arm_back();
void Arm_Ready_put(int8_t flag);
void Arm_Grab_floor2(uint8_t small_flag);
void Arm_Grab_floor3();
//void Arm_Detect(uint8_t floor);	
//void Arm_Put(void);
// ״̬ö�ٶ���
typedef enum {
    STATE_INITIAL,       // 0: ��ʼλ��
	  STATE_DETECT,
    STATE_PRE_GRAB_L1,   // 1: 1��Ԥץȡ��������
    STATE_GRAB_L1,       // 2: 1��ץȡ
	  STATE_GRAB_L1_2,//1��ץȡ�����
    STATE_PUT,          // 
    STATE_GRAB_L3, // 4: 3����ת
    STATE_PRE_BACK,      // 5: �ϼ�
    STATE_GRAB_L2,       // 6: 2��ץȡ
	  STATE_GRAB_L2_2,
	  STATE_BACK,          // ������
    NUM_STATES           // 7: ״̬����
} StateIndex;


//void Arm_back();
//void State2State(int*,double);
void ExecuteServo0(uint16_t angle);
void ExecuteState(StateIndex state);
void ExecuteState_Nodelay(StateIndex state);

void go_back(float target_speed,uint32_t Delay);
void go_straight(float target_speed,uint32_t Delay);
#endif


