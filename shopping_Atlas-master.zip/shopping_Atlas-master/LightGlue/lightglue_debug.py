import cv2
import numpy as np
def main_rect_select_fixed_ratio_3_4(image_path="list_img\\2.png"):
    window_name = "ROI Selector (Fixed Ratio 3:4)"
    cv2.namedWindow(window_name)

    frame = cv2.imread(image_path)
    if frame is None:
        print(f"❌ 无法加载图片: {image_path}")
        return

    height, width = frame.shape[:2]
    center_x, center_y = width // 2, height // 2
    rect_height = min(height, width * 4 // 3)  # 调整为竖向矩形
    rect_width = rect_height * 3 // 4

    pt1 = (center_x - rect_width // 2, center_y - rect_height // 2)
    pt2 = (center_x + rect_width // 2, center_y + rect_height // 2)
    dragging_point = None

    def mouse_callback(event, x, y, flags, param):
        nonlocal pt1, pt2, dragging_point
        if event == cv2.EVENT_LBUTTONDOWN:
            if abs(x - pt1[0]) < 10 and abs(y - pt1[1]) < 10:
                dragging_point = 'top-left'
            elif abs(x - pt2[0]) < 10 and abs(y - pt2[1]) < 10:
                dragging_point = 'bottom-right'
            elif pt1[0] < x < pt2[0] and pt1[1] < y < pt2[1]:
                dragging_point = 'move'
        elif event == cv2.EVENT_MOUSEMOVE:
            if dragging_point == 'top-left':
                pt1 = (x, y)
            elif dragging_point == 'bottom-right':
                pt2 = (x, y)
            elif dragging_point == 'move':
                dx, dy = x - (pt1[0] + pt2[0]) // 2, y - (pt1[1] + pt2[1]) // 2
                pt1 = (pt1[0] + dx, pt1[1] + dy)
                pt2 = (pt2[0] + dx, pt2[1] + dy)
        elif event == cv2.EVENT_LBUTTONUP:
            dragging_point = None

        w = pt2[0] - pt1[0]
        h = pt2[1] - pt1[1]
        if w > 0 and h > 0:
            aspect_ratio = 3 / 4  # 竖向比例
            if w / h > aspect_ratio:
                new_h = w / aspect_ratio
                pt2 = (pt2[0], int(pt1[1] + new_h))
            else:
                new_w = h * aspect_ratio
                pt2 = (int(pt1[0] + new_w), pt2[1])

    cv2.setMouseCallback(window_name, mouse_callback)

    while True:
        display_frame = frame.copy()
        cv2.rectangle(display_frame, pt1, pt2, (255, 0, 0), 2)
        cv2.imshow(window_name, display_frame)

        paperPoint = np.float32([pt1, pt2, (pt1[0], pt2[1]), (pt2[0], pt1[1])])

        print("[[" + str(paperPoint[0][0]) + ", " + str(paperPoint[0][1]) + "], "
      "[" + str(paperPoint[1][0]) + ", " + str(paperPoint[1][1]) + "], "
      "[" + str(paperPoint[2][0]) + ", " + str(paperPoint[2][1]) + "], "
      "[" + str(paperPoint[3][0]) + ", " + str(paperPoint[3][1]) + "]]")

        key = cv2.waitKey(1) & 0xFF
        if key == ord('q'):
            break

    cv2.destroyAllWindows()

if __name__ == "__main__":
     main_rect_select_fixed_ratio_3_4(image_path="D:\Robot_supermarket_shopping_2025\Robot_my_projects\shopping_Atlas-master\LightGlue\\target\\given.png")
    #  main_rect_select_fixed_ratio_3_4(image_path="D:\\Robot_supermarket_shopping_2025\\Robot_my_projects\\shopping_Atlas-master\\LightGlue\\target\\judge.png")