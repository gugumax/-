import os
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"

from pathlib import Path
from .lightglue import LightGlue, SuperPoint, DISK
from .lightglue.utils import load_image, rbd
from .lightglue import viz2d
import torch
import matplotlib.pyplot as plt
import cv2
import numpy as np
judge_final_index = 0  # 用于区分不同次保存的 judgeFinal_x.png
########## 下面是匹配函数
def lightglue_match(LightGlue_config,lightglue_ismatch_value,verbose=False):
    
    global judge_final_index  # 引用全局索引
    # 调用匹配函数
    success = lightglue_preprocess(LightGlue_config)
    # if success:
    #     print("两张图像裁剪成功！可以进行下一步特征匹配。")
    # else:
    #     print("裁剪失败，请检查图像路径或坐标是否在图像范围内。")

    given_final = LightGlue_config["saveGivenFinal"]
    judge_final = LightGlue_config["saveJudgeFinal"]

    # 新增：生成带编号的保存路径
    indexed_judge_final = LightGlue_config["saveJudgeFinalWithIndex"].format(judge_final_index)
    img = cv2.imread(judge_final)
    cv2.imwrite(indexed_judge_final, img)
    judge_final_index += 1  # 更新索引

    match_count, success = match_images(judge_final, given_final, verbose)
    if success and match_count > lightglue_ismatch_value:  # 设定阈值判断是否相似
        print(f"找到 {match_count} 个匹配点,匹配成功")
        return True
        # 在这里可以加入机器人动作逻辑
    else:
        print(f"找到 {match_count} 个匹配点,匹配失败")
        return False
## 处理图像裁剪
def crop_image(img_path, save_path, roi_points):
    """
    根据给定的四个点坐标裁剪图像并保存
    :param img_path: 原始图像路径
    :param save_path: 裁剪后图像保存路径
    :param roi_points: 矩形区域的4个点 [[x1,y1], [x2,y2], [x3,y3], [x4,y4]]
    :return: 成功返回 True，失败返回 False
    """
    # 读取图像
    img = cv2.imread(img_path)
    if img is None:
        print(f"❌ 图像读取失败：{img_path}")
        return False

    # 提取最小外接矩形
    pts = np.array(roi_points, dtype=np.int32)
    x, y, w, h = cv2.boundingRect(pts)

    # 防止越界
    height, width = img.shape[:2]
    x = max(x, 0)
    y = max(y, 0)
    w = min(w, width - x)
    h = min(h, height - y)

    # 裁剪图像
    cropped_img = img[y:y+h, x:x+w]

    # 保存结果
    cv2.imwrite(save_path, cropped_img)
    print(f" 已保存裁剪图像至 {save_path}")
    return True
### 处理给定图像和待测图像
def lightglue_preprocess(config):
    """
    根据 LightGlue_config 执行图像裁剪操作
    :param config: 包含图像路径和裁剪区域的字典
    """
    # 处理 given 图像
    success_given = crop_image(
        img_path=config["imgGiven"],
        save_path=config["saveGivenFinal"],
        roi_points=config["paperPointsGiven"]
    )

    # 处理 judge 图像
    success_judge = crop_image(
        img_path=config["imgJudge"],
        save_path=config["saveJudgeFinal"],
        roi_points=config["paperPointsJudge"]
    )

    if success_given and success_judge:
        print(" 给定图像与待测图像裁剪完成")
    else:
        print("⚠️ 裁剪过程中有图像处理失败，请检查输入图像或坐标")

    return success_given and success_judge



########## 下面是匹配函数
def match_images(image0_path, image1_path, verbose=False):
    """
    使用 SuperPoint + LightGlue 匹配两张图片，返回匹配点数量。
    
    参数:
        image0_path (str): 目标图像路径（如 judge.jpg）
        image1_path (str): 参考图像路径（如 given.png）
        verbose (bool): 是否打印详细信息
    
    返回:
        int: 匹配的关键点对数量
        bool: 是否匹配成功
    """
    try:
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        if verbose:
            print(f"Using device: {device}")

        # 初始化模型
        extractor = SuperPoint(max_num_keypoints=2048).eval().to(device)
        matcher = LightGlue(features="superpoint").eval().to(device)

        # 加载图像
        if verbose:
            print(f"Loading images: {image0_path}, {image1_path}")
        image0 = load_image(image0_path).to(device)
        image1 = load_image(image1_path).to(device)

        # 提取特征
        feats0 = extractor.extract(image0)
        feats1 = extractor.extract(image1)

        # 特征匹配
        matches01 = matcher({"image0": feats0, "image1": feats1})
        feats0, feats1, matches01 = [rbd(x) for x in [feats0, feats1, matches01]]
##############################3
        # kpts0 = feats0["keypoints"].cpu().numpy()
        # kpts1 = feats1["keypoints"].cpu().numpy()
        # matches = matches01["matches"].cpu().numpy()

        # match_count = len(matches)
        # success = match_count > 0  # 简单判断是否有匹配

        # # ===== 新增可视化部分 =====
        # if verbose or not success:
        #     # 获取原始图像用于显示

        #     image0_np = load_image(image0_path).cpu().numpy().transpose(1, 2, 0)  # CHW -> HWC
        #     image1_np = load_image(image1_path).cpu().numpy().transpose(1, 2, 0)

        #     # 显示图像并绘制关键点
        #     plt.figure(figsize=(12, 6))
        #     plt.subplot(1, 2, 1)
        #     plt.imshow(image0_np)
        #     plt.scatter(kpts0[:, 0], kpts0[:, 1], c='red', s=5)
        #     plt.title("Image 0 Keypoints")

        #     plt.subplot(1, 2, 2)
        #     plt.imshow(image1_np)
        #     plt.scatter(kpts1[:, 0], kpts1[:, 1], c='red', s=5)
        #     plt.title("Image 1 Keypoints")
        #     plt.show()

        #     # 绘制匹配线
        #     viz2d.plot_images([image0_np, image1_np])
        #     if len(matches) > 0:
        #         m_kpts0 = kpts0[matches[:, 0]]
        #         m_kpts1 = kpts1[matches[:, 1]]
        #         viz2d.plot_matches(m_kpts0, m_kpts1, color="lime", lw=0.5)
        #         viz2d.add_text(0, f'Found {match_count} Matches')
        #     else:
        #         viz2d.add_text(0, 'No matches found', color='red')
        #     plt.show()

        #########################################
        match_count = len(matches01["matches"])
        if verbose:
            print(f"找到 {match_count} 个匹配点")

        return match_count, True  # 成功匹配

    except Exception as e:
        print(f"[错误] 图像匹配失败: {e}")
        return 0, False

# torch.set_grad_enabled(False)
# images = Path("assets")

# device = torch.device("cuda" if torch.cuda.is_available() else "cpu")  # 'mps', 'cpu'

# extractor = SuperPoint(max_num_keypoints=2048).eval().to(device)  # load the extractor
# matcher = LightGlue(features="superpoint").eval().to(device)

# # image0 = load_image('./target/judge.jpg')
# # image1 = load_image('./target/given.png')
# image0 = load_image('E:/Activity/Robot/Robot9th/CODE/2025_shopping_master/LightGlue/target/judge.jpg')
# image1 = load_image('E:/Activity/Robot/Robot9th/CODE/2025_shopping_master/LightGlue/target/given.png')

# feats0 = extractor.extract(image0.to(device))
# feats1 = extractor.extract(image1.to(device))
# matches01 = matcher({"image0": feats0, "image1": feats1})
# feats0, feats1, matches01 = [
#     rbd(x) for x in [feats0, feats1, matches01]
# ] 

# kpts0, kpts1, matches = feats0["keypoints"], feats1["keypoints"], matches01["matches"]
# m_kpts0, m_kpts1 = kpts0[matches[..., 0]], kpts1[matches[..., 1]]

# # axes = viz2d.plot_images([image0, image1])
# # viz2d.plot_matches(m_kpts0, m_kpts1, color="lime", lw=0.2)
# # viz2d.add_text(0, f'Stop after {matches01["stop"]} layers')

# # kpc0, kpc1 = viz2d.cm_prune(matches01["prune0"]), viz2d.cm_prune(matches01["prune1"])
# # viz2d.plot_images([image0, image1])
# # viz2d.plot_keypoints([kpts0, kpts1], colors=[kpc0, kpc1], ps=6)

# print(len(matches01["matches"]))
# #输出匹配点对的数量。
# # plt.show()
# #显示之前生成的所有可视化图像。
