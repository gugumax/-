from PPOCR_api import GetOcrApi
import time
# 初始化识别器对象，传入 PaddleOCR_json.exe 的路径
start_time = time.time()
ocr = GetOcrApi("./PaddleOCR-json_v1.4.1/PaddleOCR-json.exe")

# 识别图片，传入图片路径
getObj = ocr.run('D:\Robot_supermarket_shopping_2025\Robot_my_projects\shopping_Atlas-master\list_img\imgFinal.png')

# print(f'图片识别完毕，状态码：{getObj["code"]} 结果：\n{getObj["data"]}\n')
data = getObj["data"]
result = [item['text'] for item in data]
print("所有文本内容：", result)
end_time = time.time()
print(f'图片识别时间：{end_time - start_time}秒')



# start_time = time.time()
# ocrPath = './RapidOCR-json_v0.2.0/RapidOCR-json.exe'
# ocr = OcrAPI(ocrPath)
# res = ocr.run('D:\Robot_supermarket_shopping_2025\Robot_my_projects\shopping_Atlas-master\list_img\imgFinal_1.png') 

# result = [item['text'] for item in res['data']]
# print("所有文本内容：", result)
# ocr.stop()
# end_time = time.time()
# print(f'图片识别时间：{end_time - start_time}秒')