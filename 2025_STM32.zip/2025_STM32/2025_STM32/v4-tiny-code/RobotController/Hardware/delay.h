#ifndef _DELAY_H
#define _DELAY_H

#include "main.h"

void delay_us(__IO uint32_t us);//延迟指定微秒

#endif

