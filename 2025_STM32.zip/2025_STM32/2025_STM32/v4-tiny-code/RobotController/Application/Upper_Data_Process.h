#ifndef __UPPER_DATA_PROCESS_H_
#define __UPPER_DATA_PROCESS_H_

#include "stm32f4xx.h"

void data_process(char *data);
void char_to_int(char *data);

#endif