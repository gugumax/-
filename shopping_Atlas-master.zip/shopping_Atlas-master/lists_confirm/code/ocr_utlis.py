# environment :conda activate PyProject
#              python3.7.2
# 此文件为函数工具包

 
from paddleocr import PaddleOCR
import cv2
import numpy as np
from fuzzywuzzy import process

from .PPOCR_api import GetOcrApi


object_name_ch =["锐澳","东鹏","茶Π","加多宝"]
object_map_num = [[42],[21,48],[38],[33]]       #当前最后一个标签为36
img_final_index = 0  # 用于区分不同次保存的 imgFinal_x.png

# 对字符串进行最相近的匹配，返回匹配的字符串
# 返回形式为[匹配的字符串，匹配的字符串的索引]
# input_string: 输入的字符串
# potential_matches: 可能的匹配字符串
# OnlyNum=True 时，返回的是数字,否则返回的是[字符串,索引]的列表
def closest_match_name(input_string, potential_matches):
    try:
        name,score = process.extractOne(input_string, potential_matches,score_cutoff=20)
        print(f"匹配到的物品名称: {name}, 匹配度: {score}")
    except:
        name = []
        score = 0
    return name,score
# def get_name_order(input_string, potential_matches,OnlyNum=True):
#     outputList = []
#     nameList = []
#     for stringName in input_string:
#         nameList.append(stringName)
#         obectnum = object_map_num[object_name_ch.index(stringName)]
#         if OnlyNum:
#             outputList.append(obectnum)
#         else:
#             outputList.append([nameList,obectnum])

#     return outputList

# def get_item_id(item_name):
#     """
#     输入一个物品名称（字符串），返回其在 object_map_num 中对应的编号。
#     如果找不到匹配项，返回 None。
#     """
#     try:
#         index = object_name_ch.index(item_name)
#         return object_map_num[index]
#     except ValueError:
#         print(f"未找到物品 '{item_name}' 的对应编号")
#         return None

# # 将字符转为数字，并且判断数字是否大于2或者有0的情况
# def formulateNum(string):
#     if int(string)>2:
#         return 2
#     elif int(string)==0:
#         return 1
#     else:
#         return int(string)

def paddle_ocr(img_path):
    # ocr = PaddleOCR(lang='ch', use_angle_cls=True)
    # result = ocr.ocr(img_path, cls=True)[0]

    # # 提取所有识别出的文字内容
    # raw_texts = [res[1][0] for res in result]
    ocr = GetOcrApi("D:/Robot_supermarket_shopping_2025/Robot_my_projects/shopping_Atlas-master/PaddleOCR-json_v1.4.1/PaddleOCR-json.exe")
    img_path  = 'D:\Robot_supermarket_shopping_2025\Robot_my_projects\shopping_Atlas-master\list_img\imgFinal.png'

    # 识别图片，传入图片路径
    getObj = ocr.run(img_path)
    ocr.exit()  # 结束引擎子进程
    # print(f'图片识别完毕，状态码：{getObj["code"]} 结果：\n{getObj["data"]}\n')
    data = getObj["data"]
    raw_texts = [item['text'] for item in data]
    # 模糊匹配到预设物品名
    matched_name = None

    match_results = []
    print("识别的所有文字：", raw_texts)
    for text in raw_texts:
        match_name,score = closest_match_name(text, object_name_ch)
        match_results.append((text, match_name, score))
        # if match_name not in ['物品名称', '物品数量']:  # 排除无意义字段
        # matched_name = match_name
        # break  # 找到第一个有效匹配项即返回
    if match_results:
    # 找到得分最高的项
        best_match = max(match_results, key=lambda x: x[2])
        matched_text,matched_name, best_score = best_match
        # print(f"识别的初始文字:{matched_text},得分最高的匹配：{matched_name}，分数：{best_score}")
    else:
        matched_name, best_score = None, 0
        print("未找到有效匹配项")
        return []
    # if matched_name is None:
    #     print("未找到任何匹配的物品名称")
    #     return []

    # 获取对应编号
    item_id = object_map_num[object_name_ch.index(matched_name)]

    print("识别并匹配到的物品：", matched_name)
    print("对应编号：", item_id)
    return item_id

# def paddle_ocr(img_path):
#     # Paddleocr目前支持的多语言语种可以通过修改lang参数进行切换
#     # 例如`ch`, `en`, `fr`, `german`, `korean`, `japan` 
#     ocr = PaddleOCR(lang='ch',use_angle_cls=True,)  # 直接选择中英文混合模式

#     #调用模型获取处理结果
#     result = ocr.ocr(img_path, cls=True)[0]
#     content = []
    
#     # purpose：接下来选取数计算中心坐标，并且添加到原列表中
#     # content：[左上 右上 左下 右下]

#     for idx in range(len(result)):
#         res = result[idx]
#         content_line =[]

        
#         column = res[1][0]
 
#         # 计算中心坐标
#         p1, p2, p3, p4 = res[0]
#         x_center = (p1[0] + p3[1]) / 2
#         y_center = (p1[1] + p3[1]) / 2
#         content.append([(x_center,y_center),column])

#     ## 分两种情况考虑，这是第一种情况，按行排列
#     y_buff = 0                   #记录下上一次y值
#     x_min = 9999999              #寻找最左端的x值作为参考
#     content_diff_line = []       #每一行的元素
#     x_distence_line = []   #每一行的间距

#     result_final = []                  #最终的结果
    
#     for i in range(len(content)):
#         content_line = content[i]
#         x = content_line[0][0]
#         y = content_line[0][1]
        
#         if x<x_min:
#             x_min = x
        
#         if y-y_buff> 5 and i!=0 :
#             result_final.append(content_diff_line)
#             content_diff_line = [] #该行结束，清空数据
            
#         content_diff_line.append(content_line[1])  
#         x_distence_line.append(x) 
#         y_buff = y     #记录下y坐标
#     result_final.append(content_diff_line)
#     print(result_final)
#     #=========================================================
#     object_name = []
#     object_num = []
#     isNum = False
#     isName = False
#     for result in result_final:
#         for res in result:
#             if len(res)>=2 and not res.isdigit():
#                 match_name = closest_match_name(res,object_name_ch)    # 获取最相近的字符串
#                 if match_name == '物品名称' or match_name=="物品数量":
#                     result.remove(res)
#                 else:
#                     if (isName):
#                         object_num.append(1)
#                     object_name.append(match_name)
#                     isName = True
#                     isNum = False
#             else:# 此时为数字
#                 # 考虑出现清单A中情况，如果出现，此时物品数量只能为1 
#                 if len(object_name)!=0 and object_name[-1] in object_name_orderA:
#                     object_num.append(1)
#                 elif res.isdigit():
#                     if res == '2':
#                         object_num.append(2)
#                     else:
#                         object_num.append(1)
#                 isName = False
#                 isNum = True
#     # 如果最后一个数字未识别到，添加1
#     while len(object_num)<len(object_name):
#         object_num.append(1)
#     print(object_name)  
#     print(object_num)                 
            
#     object_name = get_name_order(object_name,object_name_ch)
      
#     return object_name,object_num

# # 图像处理
# def get_object_name_num(ocr_config):
#     img = cv2.imread(ocr_config["saveImgPath"])
#     # 创建锐化核
#     kernel = np.array([[-1,-1,-1], [-1,9,-1], [-1,-1,-1]])
#     # 使用cv2.filter2D方法锐化图像
#     img=cv2.filter2D(img, -1, kernel * ocr_config["sharpness"])
#     # 进行图像增强  
#     alpha = ocr_config["Brightness"] # 对比度增强参数
#     beta = ocr_config["Contrast"]  # 亮度增强参数
#     img = cv2.convertScaleAbs(img, alpha=alpha, beta=beta)
    
#     ob_name = paddle_ocr(img)
#     return ob_name
def get_object_name_num(ocr_config, index=None):
    if index is not None:
        img_path = ocr_config["saveImgPathWithIndex"].format(index)
    else:
        img_path = ocr_config["saveImgPath"]

    img = cv2.imread(img_path)
    if img is None:
        print(f"无法读取图像: {img_path}")
        return []

    # 创建锐化核
    kernel = np.array([[-1,-1,-1], [-1,9,-1], [-1,-1,-1]])
    img = cv2.filter2D(img, -1, kernel * ocr_config["sharpness"])
    
    # 对比度和亮度增强
    alpha = ocr_config["Brightness"]
    beta = ocr_config["Contrast"]
    img = cv2.convertScaleAbs(img, alpha=alpha, beta=beta)

    ob_name = paddle_ocr(img)
    return ob_name

def ChecklistOCR(ocr_config):
    global img_final_index  # 引入全局索引变量

    widthImg = ocr_config["widthImg"]
    heightImg = ocr_config["heightImg"]
    angle = ocr_config["rotation"]
    if angle:
        angle = 90
    else:
        angle = 0

    try:
        # 只加载指定索引的图片
        img_path = ocr_config["imgPath"] + '\\' + str(img_final_index) + '.png'
        img = cv2.imread(img_path)
        if img is None:
            print(f"无法读取图片: {img_path}")
            return []

        imgOriginal = img.copy()
        imgOriginal = cv2.resize(imgOriginal, (widthImg, heightImg))

        # 透视变换等操作保持不变
        pts1 = np.float32(ocr_config["paperPoints"])
        pts2 = np.float32([[0, 0], [widthImg, 0], [0, heightImg], [widthImg, heightImg]])
        paperMatrix = cv2.getPerspectiveTransform(pts1, pts2)
        imgpaper = cv2.warpPerspective(imgOriginal, paperMatrix, (widthImg, heightImg))

        (h, w) = imgpaper.shape[:2]
        imgpaper = cv2.resize(imgpaper, (w, w))
        center = (w // 2, w // 2)
        imgpaper = cv2.warpAffine(imgpaper, cv2.getRotationMatrix2D(center, angle, 1.0), (w, w))

        # 保存最终图片到固定路径和带编号的历史图
        cv2.imwrite(ocr_config["saveImgPath"], imgpaper)

        save_path_indexed = ocr_config["saveImgPathWithIndex"].format(img_final_index)
        cv2.imwrite(save_path_indexed, imgpaper)
        print(f"已保存历史图像: {save_path_indexed}")
        img_final_index += 1

        # OCR 核心逻辑
        ob_name = get_object_name_num(ocr_config)
    except Exception as e:
        print(f"图片处理失败: {e}")
        ob_name = []

    return ob_name

# 图片调试
# def ChecklistOCR(ocr_config):
#     global img_final_index  # 引入全局索引变量

#     widthImg = ocr_config["widthImg"]
#     heightImg = ocr_config["heightImg"]
#     angle = ocr_config["rotation"]
#     if angle:
#         angle = 90
#     else:
#         angle = 0
#     for i in range(0,3):
#         try:
#             img = cv2.imread(ocr_config["imgPath"]+'\\'+str(i)+'.png')
#     ##==========================================开始=============================================
#             imgOriginal = img.copy()
#             imgOriginal = cv2.resize(imgOriginal, (widthImg, heightImg))

        
#     ##==========================================获取边框=================================================
        

#     ##==========================================透视变化=================================================
#             pts1 = np.float32(ocr_config["paperPoints"])
#             pts2 = np.float32([[0,0],[widthImg,0],[0,heightImg],[widthImg,heightImg]])
#             paperMatrix = cv2.getPerspectiveTransform(pts1, pts2)#获得变化矩阵
#             imgpaper = cv2.warpPerspective(imgOriginal, paperMatrix, (widthImg, heightImg))
            
#             (h, w) = imgpaper.shape[:2]
#             imgpaper = cv2.resize(imgpaper, (w , w))
#             # 计算旋转中心点
#             center = (w // 2, w // 2)       
#             imgpaper = cv2.warpAffine(imgpaper, cv2.getRotationMatrix2D(center, angle, 1.0), (w, w))
#             cv2.imwrite(ocr_config["saveImgPath"], imgpaper)
            
#             # 保存带编号的历史图，例如：imgFinal_0.png
#             save_path_indexed = ocr_config["saveImgPathWithIndex"].format(img_final_index)
#             cv2.imwrite(save_path_indexed, imgpaper)
#             print(f"已保存历史图像: {save_path_indexed}")
#             img_final_index += 1  # 索引自增
            
#         except:
#             print("图片处理失败")
#             pass
#         # cv2.imshow("imgpaper",imgpaper)
#         # cv2.waitKey(0)  
#     try:
#         ob_name= get_object_name_num(ocr_config)
#     except:
#         ob_name = []
       
#     return ob_name