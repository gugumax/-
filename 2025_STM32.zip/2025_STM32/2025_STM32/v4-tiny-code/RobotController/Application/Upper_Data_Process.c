#include "Upper_Data_Process.h"
#include "string.h"
#include "chassis_move.h"
#include "Stepper_Motor.h"
#include "ArmSolution.h"
#include "stdio.h"

int16_t ValidData[12];

void char_to_int(char *data)
{
	uint8_t temp[12]={0};
	ValidData[1]=data[1];
	for(uint8_t i=2;i<12;i++)
	{
		ValidData[i]=data[i]-'0';
	}
}

void data_process(char *data)
{
	char_to_int(data); //字符串转数值
	switch (ValidData[1])
	{
		case 'M':  //Move移动
		{
			float target_theta=ValidData[2]+ValidData[4]*0.1+ValidData[5]*0.01; //ValidData[3] is point
			float speed=ValidData[6]*100+ValidData[7]*10+ValidData[8];
			uint8_t Is_detecting = ValidData[9];
			uint8_t rotation_direction = ValidData[10];
//			if(Is_detecting==0){
				switch(rotation_direction){
					case 0: chassis_move(speed,target_theta,0); break;
					case 1: chassis_move(speed,target_theta,0.15); break; // 逆时针直线
					case 2: chassis_move(speed,target_theta,-0.15); break; // 顺时针直线
					default: break;
				}
//			}
//			else if(Is_detecting==1)
//			{
//				if(direction==0) //go forward&right
//						chassis_move(80,0.14,-0.03);
//				else if(direction==1) //go forward&left
//					chassis_move(80,3.00,0.03);
//			}
			break;
		}
		case 'F': //Fast go
		{
			float target_theta=ValidData[2]+ValidData[4]*0.1+ValidData[5]*0.01; //ValidData[3] is point
			float speed=ValidData[6]*100+ValidData[7]*10+ValidData[8];
			uint8_t Is_detecting = ValidData[9];
			uint8_t rotation_direction = ValidData[10];
//			if(Is_detecting==0){
				switch(rotation_direction){
					case 0: chassis_move(speed,target_theta,0); break;
					case 1: chassis_move(speed,target_theta,0.3); break; // 逆时针直线
					case 2: chassis_move(speed,target_theta,-0.3); break; // 顺时针直线
					default: break;
				}
//			}
//			else if(Is_detecting==1)
//			{
//				if(direction==0) //go forward&right
//						chassis_move(80,0.14,-0.03);
//				else if(direction==1) //go forward&left
//					chassis_move(80,3.00,0.03);
//			}
			break;
		}
		case 'R': //Ready put
		{
			int8_t flag=ValidData[2];
			Arm_Ready_put(flag);
			printf("ok\n");
			break;
		}
		case 'C': //Correct往前移动一小段距离
		{
			chassis_move(100,1.57,0);
			HAL_Delay(1);
			break;
		}
		case 'S': //Stopֹͣ
		{
			chassis_move(0,0,0);
			break;
		}
		case 'G': //Arm
		{			
			int8_t Grab_floor=ValidData[2];
			uint8_t small_flag = ValidData[3];
			if(Grab_floor==1)
			{
				Arm_Grab_floor1();
			}
			else if(Grab_floor==2)
			{
				Arm_Grab_floor2(small_flag);
			}
			else if(Grab_floor==3)
			{
				Arm_Grab_floor3();
			}
			while(!ServoTunnerOK());
			printf("ok\n");
			break;
		}
		case 'P': //伸出手臂
		{
			ExecuteState(STATE_PUT);
			printf("ok\n");
			break;
		}
		case 'N': //放下
		{
			ExecuteState(STATE_GRAB_L3);
			HAL_Delay(500);
			ExecuteServo0(Servo0_OPEN_Angle);
			ExecuteState(STATE_PUT);
			HAL_Delay(500);
			SetServoAngle(1, 140);
			while(!ServoTunnerOK());
			printf("ok\n");
			break;
		}
		case 'D':  //detect
		{
			uint8_t floor = ValidData[2];
			uint8_t flag = ValidData[3];
			if(floor==1)                 //detect the lists
			{
				ExecuteState(STATE_DETECT);
				Stepper_motor_goto_height(Stepper_Position[1], flag);
			}
			else if(floor==2)
			{
				ExecuteState(STATE_DETECT);
				Stepper_motor_goto_height(Stepper_Position[2], flag);
			}
			else if(floor==3)
			{
				ExecuteState(STATE_DETECT);
				Stepper_motor_goto_height(Stepper_Position[3], flag);
			}
			printf("ok\n");
			break;
		}
		case 'B': //Back
		{
			uint8_t flag = ValidData[2];
			if(flag == 0)  //小的物品
			{
				Arm_back();
			}
			else //大的物品
			{

			}
			printf("ok\n");
			break;
		}
		case 'H': //Hou Tui
		{
			chassis_move(100,4.71,0);
			break;
		}
		case 'O': // 倒货物
		{
			HAL_Delay(1);
			printf("ok\n");
			break;
		}
		case 'J': //Rotate自转
		{
			uint8_t flag = ValidData[2];
			int error=ValidData[3]*100+ValidData[4]*10+ValidData[5];
			if(flag == 0)
				error = -error;
			else if(flag == 1)
				error = error;
			chassis_jiaozi(error);
			printf("ok\n");
			break;
		}

	}
		
}


