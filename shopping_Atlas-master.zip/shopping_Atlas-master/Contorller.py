import serial
import time
from math import atan2, pi
# ser = serial.Serial('COM6', 115200)  # 请根据实际情况修改串口号和波特率  \\\\.\\COM12
from serial.tools import list_ports
def find_CH340_port():
    ports = list_ports.comports()
    for port in ports:
        if "CH340" in port.description:
            print(f"打开串口成功{port}")
            return port.device
    # return None

port = find_CH340_port()
if port is not None:
    ser = serial.Serial(port, 115200)
else:
    print("没有找到包含'CH340'的串口")

is_rotation = False
#通信格式 0x42(B):数据帧头 0x5A(Z):数据帧尾  M(move):底盘移动  R(revolve)：底盘旋转  A(arm)：机械臂移动  S(stop)：底盘停止  D(detect):探测货架 Z:数据帧尾  
def robot_sendgoal(Cur_x, Cur_y, Cur_theta, x, y, theta, speed, Is_detecting): # Is_detecting 0 :不探测 1：探测
    # theta 取值 [0-360)
    global is_rotation
    rotation_direction = 0 # 0:不自转 1:逆时针 2:顺时针
    # if(Is_detecting == 0):
        # 计算运动方向
    target_theta=atan2((Cur_y-y),(x-Cur_x)) # 计算结果在-pi到pi之间
    target_theta += Cur_theta * (pi / 180) # 加上偏移角度
    if target_theta<0:
        target_theta += 2 * pi
    target_theta=(target_theta)%(2*pi) # 计算结果在0到2pi之间
    # 计算自转方向
    theta = theta % 360 # 归一化到0-360之间
    Cur_theta = Cur_theta % 360 # 归一化到0-360之间
    angle_diff = theta - Cur_theta # 计算目标角度与当前角度的差值
    if angle_diff > 180:
        angle_diff -= 360
    elif angle_diff < -180:
        angle_diff += 360
    if is_rotation == False and abs(angle_diff) > 3: # 如果当前没有自转且角度差大于3度，则开始自转
        if angle_diff > 0:
            rotation_direction = 2
        elif angle_diff < 0:
            rotation_direction = 1
        is_rotation = True
    elif is_rotation == True and abs(angle_diff) > 2: # 如果当前正在自转且角度差小于2度，则停止自转
        if angle_diff > 0:
            rotation_direction = 2
        elif angle_diff < 0:
            rotation_direction = 1
    else:
        is_rotation = False
    # 发送数据给下位机
    target_theta_str = "{:.2f}".format(target_theta)  # 使用format函数保留两位小数
    instruction = f'BM{target_theta_str}{str(speed).zfill(3)}{str(Is_detecting).zfill(1)}{str(rotation_direction).zfill(1)}Z'
    ser.write(instruction.encode('utf-8'))
    return abs(angle_diff)
    # elif(Is_detecting == 1):
    #     instruction = f'BMTTTTTTT{str(Is_detecting).zfill(1)}{str(direction).zfill(1)}Z'
    #     ser.write(instruction.encode('utf-8'))
    # print(instruction)

def robot_sendgoal_fast(Cur_x, Cur_y, Cur_theta, x, y, theta, speed, Is_detecting): # Is_detecting 0 :不探测 1：探测
    # theta 取值 [0-360)
    global is_rotation
    rotation_direction = 0 # 0:不自转 1:逆时针 2:顺时针
    # if(Is_detecting == 0):
        # 计算运动方向
    target_theta=atan2((Cur_y-y),(x-Cur_x)) # 计算结果在-pi到pi之间
    target_theta += Cur_theta * (pi / 180) # 加上偏移角度
    if target_theta<0:
        target_theta += 2 * pi
    target_theta=(target_theta)%(2*pi) # 计算结果在0到2pi之间
    # 计算自转方向
    theta = theta % 360 # 归一化到0-360之间
    Cur_theta = Cur_theta % 360 # 归一化到0-360之间
    angle_diff = theta - Cur_theta # 计算目标角度与当前角度的差值
    if angle_diff > 180:
        angle_diff -= 360
    elif angle_diff < -180:
        angle_diff += 360
    if is_rotation == False and abs(angle_diff) > 3: # 如果当前没有自转且角度差大于3度，则开始自转
        if angle_diff > 0:
            rotation_direction = 2
        elif angle_diff < 0:
            rotation_direction = 1
        is_rotation = True
    elif is_rotation == True and abs(angle_diff) > 2: # 如果当前正在自转且角度差小于2度，则停止自转
        if angle_diff > 0:
            rotation_direction = 2
        elif angle_diff < 0:
            rotation_direction = 1
    else:
        is_rotation = False
    # 发送数据给下位机
    target_theta_str = "{:.2f}".format(target_theta)  # 使用format函数保留两位小数
    instruction = f'BF{target_theta_str}{str(speed).zfill(3)}{str(Is_detecting).zfill(1)}{str(rotation_direction).zfill(1)}Z'
    ser.write(instruction.encode('utf-8'))
    return abs(angle_diff)
    # elif(Is_detecting == 1):
    #     instruction = f'BMTTTTTTT{str(Is_detecting).zfill(1)}{str(direction).zfill(1)}Z'
    #     ser.write(instruction.encode('utf-8'))
    # print(instruction)              
def robot_posecorrect(times):
    instruction = f'BCTTTTTTTTTZ'
    ser.write(instruction.encode('utf-8'))        
    time.sleep(times)
    robot_stop()
    #print('前进结束\n')

def robot_poseback(times):  
    instruction = f'BHTTTTTTTTTZ'   
    ser.write(instruction.encode('utf-8'))
    time.sleep(times)
    robot_stop()
    #print('后退结束\n')
    
def read_ok():
    while True:
        # 清除缓存中的所有数据
        while ser.in_waiting:
            ser.read(ser.in_waiting)
        data = ser.readline().decode('utf-8')
        # print(data)
        if data == 'ok\n':
            #print('stm32_ok\n')
            break    
    
def robot_detect(floor, flag): #探测不同层数时的机械臂高度 falg 0:不延时 1:延时
    instruction = f'BD{str(floor).zfill(1)}{str(flag).zfill(1)}TTTTTTTZ'
    ser.write(instruction.encode('utf-8'))
    read_ok()
    
def robot_stop():
    ser.write('BSTTTTTTTTTZ'.encode('utf-8'))
    # print('stop\n')
    #print('成功停止\n')

def robot_grab(Grab_floor, small_flag = 0): #夹取物品
    instruction = f'BG{str(Grab_floor).zfill(1)}{str(small_flag).zfill(1)}TTTTTTTZ'
    ser.write(instruction.encode('utf-8'))
    read_ok()
def robot_back(mode): #放到箱子里
    instruction = f'BB{str(mode).zfill(1)}TTTTTTTTZ'
    ser.write(instruction.encode('utf-8'))
    read_ok()

def robot_ready_put(flag): #步进电机flag：0:不延时 1:延时
    instruction = f'BR{str(flag).zfill(1)}TTTTTTTTZ'
    ser.write(instruction.encode('utf-8'))
    read_ok()
    #print('自转结束\n')
def robot_put(): #伸出手臂
    ser.write('BPTTTTTTTTTZ'.encode('utf-8'))
    read_ok()

def robot_put_down(): #放下
    ser.write('BNTTTTTTTTTZ'.encode('utf-8'))
    read_ok()


# 示例：让机器人向x轴移动
# while True:
#     robot_sendgoal(10, 0, 0,0)
# time.sleep(1)
#     robot_stop()
#     arm_move(2000,1)


  #  ser.close()