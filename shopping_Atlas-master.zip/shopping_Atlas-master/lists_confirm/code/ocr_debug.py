import cv2
import numpy as np

# 创建可拖动的点
class DraggablePoint:
    def __init__(self, pos):
        self.pos = pos
        self.dragging = False

    def mouse_event(self, event, x, y, flags, param):
        # 当鼠标左键按下时，如果鼠标位置接近点的位置，则开始拖动
        if event == cv2.EVENT_LBUTTONDOWN:
            if abs(x - self.pos[0]) < 10 and abs(y - self.pos[1]) < 10:
                self.dragging = True
        # 当鼠标左键释放时，停止拖动
        elif event == cv2.EVENT_LBUTTONUP:
            self.dragging = False
        # 当鼠标移动且正在拖动时，更新点的位置
        elif event == cv2.EVENT_MOUSEMOVE and self.dragging:
            self.pos = (x, y)

# 创建滑块
def create_sliders(window_name):
    # 创建亮度、对比度、锐度和噪点消除滑块
    # cv2.createTrackbar('Brightness', window_name, 0, 100, lambda x: None)
    # cv2.createTrackbar('Contrast', window_name, 0, 520, lambda x: None)
    # cv2.createTrackbar('Sharpness', window_name, 50, 100, lambda x: None)
    cv2.createTrackbar('Rotation', window_name, 0, 1,lambda x: None)
    

# 调整亮度和对比度
def adjust_brightness_contrast(image, clipLimit):
    # 调整亮度和对比度的值
    cl = cv2.createCLAHE(clipLimit=clipLimit, tileGridSize=(8, 8))

    # 使用cv2.addWeighted方法调整亮度和对比度
    return  cl.apply(image)

# 锐化图像
def sharpen_image(image, sharpness=1):
    # 创建锐化核
    kernel = np.array([[-1,-1,-1], [-1,9,-1], [-1,-1,-1]])
    # 使用cv2.filter2D方法锐化图像
    return cv2.filter2D(image, -1, kernel * sharpness)

# 消除噪点
def denoise_image(image, strength=10):
    # 使用cv2.fastNlMeansDenoisingColored方法消除噪点
    return cv2.fastNlMeansDenoisingColored(image, None, strength, strength, 7, 21)

# 矩形矫正
def rectify(image, points):
    # 创建源和目标点
    pts1 = np.float32(points)
    pts2 = np.float32([[0, 0], [image.shape[1], 0], [0, image.shape[0]], [image.shape[1], image.shape[0]]])
    # 计算透视变换矩阵
    M = cv2.getPerspectiveTransform(pts1, pts2)
    # 应用透视变换
    dst = cv2.warpPerspective(image, M, (image.shape[1], image.shape[0]))
    return dst

# 主函数
def main():
    # 创建窗口
    window_name = 'Image Enhancement'
    cv2.namedWindow(window_name)
    cv2.namedWindow('Rectified Image')
    # 创建滑块
    create_sliders(window_name)
    # 创建可拖动的点
    points = [DraggablePoint((100, 100)), DraggablePoint((200, 100)), DraggablePoint((100, 200)), DraggablePoint((200, 200))]
    # 设置鼠标回调函数
    def mouse_event(event, x, y, flags, param):
        for point in points:
            point.mouse_event(event, x, y, flags, param)
    cv2.setMouseCallback(window_name, mouse_event)
    # 打开摄像头
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        print("Error opening video capture")
        return
    # 主循环
    while True:
        # 读取帧
        ret, frame = cap.read()
        if not ret:
            print("Error reading frame")
            break
        # 获取滑块的值
        # brightness = cv2.getTrackbarPos('Brightness', window_name)
        # contrast = cv2.getTrackbarPos('Contrast', window_name)
        # sharpness = cv2.getTrackbarPos('Sharpness', window_name)
        rotation = cv2.getTrackbarPos('Rotation', window_name)
        # denoise_strength = cv2.getTrackbarPos('Denoise', window_name)
        # 在每个点上画一个圆
        for point in points:
            cv2.circle(frame, point.pos, 5, (0, 255, 0), -1)
        # 显示原始图像
        cv2.imshow(window_name, frame)
        # 矩形矫正
        rectified_frame = rectify(frame, [point.pos for point in points])
        # 调整亮度和对比度，锐化图像，消除噪点
        # rectified_frame = adjust_brightness_contrast(rectified_frame, brightness, contrast)
        rectified_frame = sharpen_image(rectified_frame, 1)
        (h, w) = rectified_frame.shape[:2]
        # 计算旋转中心点
        # if rotation:
        #     rectified_frame = cv2.resize(rectified_frame, (w, w))
        center = (w // 2, h // 2)       
        rectified_frame = cv2.warpAffine(rectified_frame, cv2.getRotationMatrix2D(center, rotation*90, 1.0), (w, h))
        # rectified_frame = denoise_image(rectified_frame, denoise_strength)
        # 显示矫正后的图像
        cv2.imshow('Rectified Image', rectified_frame)
        paperPoint = np.float32([point.pos for point in points])
        print("Paper Points Coordinates:")
        print("[[" + str(paperPoint[0][0]) + ", " + str(paperPoint[0][1]) + "], "
      "[" + str(paperPoint[1][0]) + ", " + str(paperPoint[1][1]) + "], "
      "[" + str(paperPoint[2][0]) + ", " + str(paperPoint[2][1]) + "], "
      "[" + str(paperPoint[3][0]) + ", " + str(paperPoint[3][1]) + "]]")
        print("")
        print("-" * 30)
        # 按q键退出
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
    # 释放摄像头并关闭所有窗口
    cap.release()
    cv2.destroyAllWindows()

def main_image():
    # 创建窗口
    window_name = 'Image Enhancement'
    rectified_window_name = 'Rectified Image'
    cv2.namedWindow(window_name)
    cv2.namedWindow(rectified_window_name)

    # 创建滑块
    create_sliders(window_name)

    # 加载本地图片（替换为你自己的路径）
    image_path = "D:\Robot_supermarket_shopping_2025\Robot_my_projects\shopping_Atlas-master\list_img\\3.png"
    frame = cv2.imread(image_path)
    if frame is None:
        print(f"无法加载图片: {image_path}")
        return

    # 初始化可拖动的四个点（默认位置）
    points = [
        DraggablePoint((283, 283)),
        DraggablePoint((514, 282)),
        DraggablePoint((288, 409)),
        DraggablePoint((523, 408))
    ]

    # 设置鼠标回调事件
    def mouse_event(event, x, y, flags, param):
        for point in points:
            point.mouse_event(event, x, y, flags, param)
    cv2.setMouseCallback(window_name, mouse_event)

    while True:
        # 复制原始图像用于绘制点
        display_frame = frame.copy()

        # 绘制可拖动的点
        for point in points:
            cv2.circle(display_frame, point.pos, 5, (0, 255, 0), -1)

        # 显示原始图像窗口
        cv2.imshow(window_name, display_frame)

        # 获取滑块值
        rotation = cv2.getTrackbarPos('Rotation', window_name)

        # 矩形矫正
        rectified_frame = rectify(frame, [point.pos for point in points])

        # 锐化处理
        rectified_frame = sharpen_image(rectified_frame, 1)

        # 旋转处理
        (h, w) = rectified_frame.shape[:2]
        center = (w // 2, h // 2)
        rectified_frame = cv2.warpAffine(
            rectified_frame,
            cv2.getRotationMatrix2D(center, rotation * 90, 1.0),
            (w, h)
        )

        # 显示矫正后的图像
        cv2.imshow(rectified_window_name, rectified_frame)

        # 输出当前纸张区域坐标（一行输出）
        paperPoint = np.float32([point.pos for point in points])
        print("Paper Points Coordinates: [[%.1f, %.1f], [%.1f, %.1f], [%.1f, %.1f], [%.1f, %.1f]]" % (
            paperPoint[0][0], paperPoint[0][1],
            paperPoint[1][0], paperPoint[1][1],
            paperPoint[2][0], paperPoint[2][1],
            paperPoint[3][0], paperPoint[3][1]
        ))

        # 按 q 键退出
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cv2.destroyAllWindows()



   

    # 返回最终选定的矩形区域坐标（四个角点）
    # return [top_left, top_right, bottom_left, bottom_right]


if __name__ == '__main__':
    # main()
    main_image()
   