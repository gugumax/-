# NBU-RobotDriveController-v4
宁波大学机器人创新协会的机器人驱动控制器程序

适配控制板：V4_1.0、V4_1.1
采用Cubemx 6.8.1版本 和stm F4 1.27.1固件开发
 