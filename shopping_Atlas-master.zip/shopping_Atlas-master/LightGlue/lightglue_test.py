from LightGlue.tzpymain import *
LightGlue_config = {
    "imgGiven": r"LightGlue/target/given.png",
    "imgJudge": r"LightGlue/target/judge.png",
    "saveGivenFinal": r"LightGlue/target/givenFinal.png",
    "saveJudgeFinal": r"LightGlue/target/judgeFinal.png",
    "saveJudgeFinalWithIndex": r"LightGlue/target/judgeFinal_{}.png",  # 新增格式化路径
    "paperPointsGiven":([171.0, 118.0], [381.0, 398.0], [171.0, 398.0], [381.0, 118.0]),
    "paperPointsJudge":([300.0, 59.0], [500.0, 326.0], [300.0, 326.0], [500.0, 59.0]),
    "widthImg": 480,
    "heightImg": 640,
}
lightglue_ismatch_value=100
# 调用预处理函数
success = lightglue_match(LightGlue_config,lightglue_ismatch_value,verbose=True)
if success:
    print("成功")
else:
    print("失败")

# pip install -e .
# 安装项目为本地开发包（适合长期开发）

# python -m LightGlue.lightglue_test
# 这样 Python 会把 shopping_Atlas-master 视为一个顶级包，就能正确识别 LightGlue.tzpymain 模块。
# 使用 -m 模块方式运行脚本（推荐）