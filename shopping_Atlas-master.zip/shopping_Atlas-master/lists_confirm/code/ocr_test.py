from ocr_utlis import *

##==========================================参数设定=============================================
ocr_config={
    "widthImg":640,
    "heightImg":480,
    "paperPoints":([283.0, 283.0], [514.0, 282.0], [288.0, 409.0], [523.0, 408.0]),
    "rotation":False,
    "sharpness":1,
    "Brightness":1.5,
    "Contrast":-70,
    "imgPath" : ".\list_img",
    "saveImgPath":".\list_img\imgFinal.png",
    "saveImgPathWithIndex": ".\list_img\imgFinal_{}.png"  # 新增格式化路径
}

# 图片调试
ob_name= ChecklistOCR(ocr_config)
print(ob_name)
